"""
Hierarchical (indentation-aware) parser for Cisco-IOS-style running-configs.

Why this exists: ntc-templates/TextFSM parses the output of ONE specific
`show <command>` per call (tabular data). It cannot walk a full, hierarchical,
arbitrarily-ordered `show running-config` dump -- there is no template for
that, by design. This module fills that gap: it builds a lightweight tree of
top-level global lines + indented blocks (interface X, line vty 0 4, router
bgp, ...), then runs a registry of small, independent extractor functions
against that tree.

Design choices that fix the two evaluation-engine bugs from the previous
review:
  1. Absence is explicit. A control that isn't found in the config produces
     a field with value "__absent__" instead of no field at all, so the
     evaluation engine can distinguish "we never checked" from "we checked
     and it's not configured" -- which is a PASS for negative controls.
  2. One field PER INSTANCE. A control like vty exec-timeout or per-interface
     proxy-arp produces one ExtractedField per block (per vty line, per
     interface), carrying an `instance_id`, instead of collapsing every
     instance into a single dict key.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Optional
import re

ABSENT = "__absent__"


# ---------------------------------------------------------------------------
# Stage 1: build a hierarchy out of flat text
# ---------------------------------------------------------------------------

@dataclass
class ConfigBlock:
    header: str
    header_line_no: int
    children: list[str] = field(default_factory=list)
    child_line_nos: list[int] = field(default_factory=list)


@dataclass
class ParsedConfig:
    global_lines: list[tuple[int, str]]
    blocks: list[ConfigBlock]


_BLOCK_HEADER_PREFIXES = (
    "interface ", "line ", "router ", "policy-map ", "class-map ",
    "crypto ", "ip access-list", "vlan ", "aaa group server",
    "vrf definition",
)


def _is_block_header(stripped_line: str) -> bool:
    return stripped_line.lower().startswith(_BLOCK_HEADER_PREFIXES)


def parse_hierarchy(raw_config: str) -> ParsedConfig:
    """
    IOS-style configs indent block children by one or more leading spaces
    under a column-0 header line, and often close a block early with a bare
    '!'. This walks the text once, tracking the "current block" state.
    """
    lines = raw_config.splitlines()
    global_lines: list[tuple[int, str]] = []
    blocks: list[ConfigBlock] = []
    current: Optional[ConfigBlock] = None

    for i, raw_line in enumerate(lines):
        line = raw_line.rstrip()
        if not line.strip():
            continue
        if line.strip() == "!":
            current = None
            continue

        indented = raw_line.startswith((" ", "\t"))
        if indented and current is not None:
            current.children.append(line.strip())
            current.child_line_nos.append(i + 1)
            continue

        current = None
        stripped = line.strip()
        if _is_block_header(stripped):
            current = ConfigBlock(header=stripped, header_line_no=i + 1)
            blocks.append(current)
        else:
            global_lines.append((i + 1, stripped))

    return ParsedConfig(global_lines=global_lines, blocks=blocks)


# ---------------------------------------------------------------------------
# Stage 2: extractor registry -> ExtractedField (matches your NormalizedField
# shape, plus instance_id so multi-instance controls survive)
# ---------------------------------------------------------------------------

@dataclass
class ExtractedField:
    control_area: str
    value: str
    raw_line: str
    line_no: int
    instance_id: Optional[str] = None
    confidence: float = 1.0
    source_lane: str = "deterministic_hierarchical"


Extractor = Callable[[ParsedConfig], list[ExtractedField]]
_EXTRACTORS: list[Extractor] = []


def extractor(fn: Extractor) -> Extractor:
    _EXTRACTORS.append(fn)
    return fn


@extractor
def extract_hostname(cfg: ParsedConfig) -> list[ExtractedField]:
    for line_no, text in cfg.global_lines:
        m = re.match(r"^hostname\s+(\S+)", text, re.IGNORECASE)
        if m:
            return [ExtractedField("hostname", m.group(1), text, line_no)]
    return [ExtractedField("hostname", ABSENT, "", 0)]


@extractor
def extract_version(cfg: ParsedConfig) -> list[ExtractedField]:
    for line_no, text in cfg.global_lines:
        m = re.match(r"^version\s+(\S+)", text, re.IGNORECASE)
        if m:
            return [ExtractedField("version", m.group(1), text, line_no)]
    return [ExtractedField("version", ABSENT, "", 0)]


@extractor
def extract_domain_name(cfg: ParsedConfig) -> list[ExtractedField]:
    for line_no, text in cfg.global_lines:
        m = re.match(r"^ip domain-name\s+(\S+)", text, re.IGNORECASE)
        if m:
            return [ExtractedField("domain_name", m.group(1), text, line_no)]
    return [ExtractedField("domain_name", ABSENT, "", 0)]


@extractor
def extract_enable_password(cfg: ParsedConfig) -> list[ExtractedField]:
    for line_no, text in cfg.global_lines:
        if re.match(r"^enable secret(?:\s+\d+)?\s+\S+", text, re.IGNORECASE):
            return [ExtractedField("enable_password", "secret", text, line_no)]
        if re.match(r"^enable password\s+\S+", text, re.IGNORECASE):
            return [ExtractedField("enable_password", "password", text, line_no)]
    return [ExtractedField("enable_password", ABSENT, "", 0)]


@extractor
def extract_logging_buffered(cfg: ParsedConfig) -> list[ExtractedField]:
    for line_no, text in cfg.global_lines:
        m = re.match(r"^logging buffered(?:\s+(\d+))?", text, re.IGNORECASE)
        if m:
            return [ExtractedField("logging", m.group(1) or "default", text, line_no)]
    return [ExtractedField("logging", ABSENT, "", 0)]


@extractor
def extract_ssh_version(cfg: ParsedConfig) -> list[ExtractedField]:
    for line_no, text in cfg.global_lines:
        m = re.match(r"^ip ssh version\s+(\d+)", text, re.IGNORECASE)
        if m:
            return [ExtractedField("ssh_version", m.group(1), text, line_no)]
    return [ExtractedField("ssh_version", ABSENT, "", 0)]


@extractor
def extract_vty_lines(cfg: ParsedConfig) -> list[ExtractedField]:
    """One field PER vty block -- this is the multi-instance fix."""
    out = []
    for block in cfg.blocks:
        m = re.match(r"^line vty\s+(\d+\s+\d+)", block.header, re.IGNORECASE)
        if not m:
            continue
        instance = f"vty {m.group(1)}"
        value, raw = ABSENT, block.header
        for child, line_no in zip(block.children, block.child_line_nos):
            tm = re.match(r"^exec-timeout\s+(\d+)\s+(\d+)", child, re.IGNORECASE)
            if tm:
                value, raw = tm.group(1), child  # minutes
        out.append(ExtractedField(
            "vty_exec_timeout", value, raw, block.header_line_no, instance_id=instance
        ))
    return out


@extractor
def extract_interface_proxy_arp(cfg: ParsedConfig) -> list[ExtractedField]:
    """One field PER interface -- proves per-instance negative controls work."""
    out = []
    for block in cfg.blocks:
        if not block.header.lower().startswith("interface "):
            continue
        instance = block.header.split(" ", 1)[1]
        disabled = any(re.match(r"^no ip proxy-arp", c, re.IGNORECASE) for c in block.children)
        out.append(ExtractedField(
            "interface_proxy_arp",
            "disabled" if disabled else ABSENT,
            block.header, block.header_line_no, instance_id=instance,
        ))
    return out


def parse_config_to_fields(raw_config: str) -> list[ExtractedField]:
    cfg = parse_hierarchy(raw_config)
    fields: list[ExtractedField] = []
    for ext in _EXTRACTORS:
        fields.extend(ext(cfg))
    return fields
