"""
Compliance rule schema (v2).

Replaces the old ComplianceRule (single `expected_value` string-equality
model) with an explicit `check_type`, so the evaluator has a real dispatch
table instead of one overloaded string-compare branch.
"""

from __future__ import annotations
from typing import Literal, Optional
from pydantic import BaseModel

CheckType = Literal[
    "equals", "not_equals",
    "min_version", "min_value", "max_value",
    "regex_match", "in_list", "not_in_list",
    "presence_required", "absence_required",
]


class ComplianceRule(BaseModel):
    control_id: str
    framework: str
    framework_version: Optional[str] = None
    control_area: str
    title: Optional[str] = None
    check_type: CheckType = "equals"
    expected_value: Optional[str] = None     # equals/not_equals/min_version/min_value/max_value/regex_match
    expected_list: Optional[list[str]] = None  # in_list/not_in_list
    severity: str
    rationale: Optional[str] = None
    remediation_template: str
