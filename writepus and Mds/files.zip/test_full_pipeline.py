"""
Integration test: raw config TEXT -> hierarchical parse -> evaluate -> findings.

This is the exact test that was missing before: nothing here is a mock or a
hand-built fixture. It exercises the real parser and the real engine against
a config string, the same way an uploaded file would.
"""

from config_parser import parse_config_to_fields
from engine import load_rules_for_framework, evaluate

SAMPLE_CONFIG = """
building configuration...
version 15.2
hostname EDGE-RTR-01
!
enable secret 5 $1$abc$def
!
ip domain-name internal.net
!
ip ssh version 1
!
line vty 0 4
 exec-timeout 10 0
 login local
!
line vty 5 15
 login local
!
interface GigabitEthernet0/1
 ip address 10.0.0.1 255.255.255.0
 no ip proxy-arp
!
interface GigabitEthernet0/2
 ip address 10.0.1.1 255.255.255.0
!
logging buffered 64000
!
end
"""

DEVICE_ID = "test-device-001"


def run():
    fields = parse_config_to_fields(SAMPLE_CONFIG)
    assert len(fields) > 0, "parser produced zero fields -- pipeline is broken"

    rules = load_rules_for_framework("CIS")
    assert len(rules) > 0, "no CIS rules loaded"

    findings = evaluate(DEVICE_ID, fields, rules)

    print(f"{'control_id':<16}{'instance_id':<16}{'status':<14}observed")
    print("-" * 70)
    for f in findings:
        print(f"{f['control_id']:<16}{(f['instance_id'] or '-'):<16}{f['status']:<14}{f['observed_value']}")

    by_id = {(f["control_id"], f["instance_id"]): f for f in findings}

    # version 15.2 < required 15.4 -> fail
    assert by_id[("CIS-IOS-1.1", None)]["status"] == "fail"
    # hostname present -> pass
    assert by_id[("CIS-IOS-2.1", None)]["status"] == "pass"
    # ssh version 1, required 2 -> fail
    assert by_id[("CIS-IOS-4.1", None)]["status"] == "fail"
    # per-instance: Gi0/1 has "no ip proxy-arp" -> pass; Gi0/2 doesn't -> fail
    assert by_id[("CIS-IOS-4.2", "GigabitEthernet0/1")]["status"] == "pass"
    assert by_id[("CIS-IOS-4.2", "GigabitEthernet0/2")]["status"] == "fail"

    print("\nAll assertions passed -- full upload-shaped pipeline verified end to end.")


if __name__ == "__main__":
    run()
