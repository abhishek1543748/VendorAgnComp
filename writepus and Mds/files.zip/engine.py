"""
Compliance evaluation engine (v2).

Fixes, relative to the original engine.py:

1. Rule-driven comparisons: dispatches on rule.check_type instead of one
   fuzzy string-equality/substring branch, so version, numeric, regex, and
   list-membership controls are expressible.
2. Per-instance findings: a control_area with multiple NormalizedField rows
   (multiple vty lines, multiple interfaces -- each carrying instance_id)
   produces one Finding PER INSTANCE, not one Finding for whichever field
   happened to be last in the dict. This preserves which specific interface
   or line failed, which the PDF report needs for actionable remediation.
3. Explicit absence handling: a field value of "__absent__" (from the
   hierarchical parser) is a real, checkable value -- not the same as "no
   field exists at all". check_type="absence_required" /
   "presence_required" evaluate it directly; every other check_type treats
   "__absent__" as a fail (the control was never configured).
4. "No field exists at all" (the extractor for this control_area never even
   ran, or the rule references an unknown control_area) still correctly
   returns needs_review -- that's a genuine "we don't know" case, distinct
   from "we checked and it's not configured".
"""

from __future__ import annotations
import os
import glob
import re
from collections import defaultdict
from typing import Optional
import yaml

from rule_schema import ComplianceRule

CONFIDENCE_THRESHOLD = 0.75
ABSENT = "__absent__"
PACKS_DIR = os.path.join(os.path.dirname(__file__), "packs")


# ---------------------------------------------------------------------------
# Rule loading
# ---------------------------------------------------------------------------

def load_rules_for_framework(framework: str) -> list[ComplianceRule]:
    rules: list[ComplianceRule] = []
    seen_ids: set[str] = set()
    yaml_files = glob.glob(os.path.join(PACKS_DIR, "*.yaml"))
    for file_path in yaml_files:
        with open(file_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if not isinstance(data, list):
            continue
        for item in data:
            if item.get("framework") != framework:
                continue
            rule = ComplianceRule(**item)
            if rule.control_id in seen_ids:
                raise ValueError(
                    f"Duplicate control_id '{rule.control_id}' found in {file_path} "
                    f"-- control_id must be unique across all rule packs."
                )
            seen_ids.add(rule.control_id)
            rules.append(rule)
    return rules


# ---------------------------------------------------------------------------
# Comparison dispatch
# ---------------------------------------------------------------------------

def _version_tuple(v: str) -> tuple[int, ...]:
    """Pulls the leading numeric dotted segment out of a version string.
    Handles vendor version strings like '15.2(4)M3' by taking '15.2'."""
    m = re.match(r"^(\d+(?:\.\d+)*)", v.strip())
    if not m:
        return tuple()
    return tuple(int(p) for p in m.group(1).split("."))


def _check_single(value: str, rule: ComplianceRule) -> Optional[bool]:
    """Returns True (pass), False (fail), or None (cannot evaluate -> needs_review)."""
    ct = rule.check_type

    if ct == "presence_required":
        return value != ABSENT
    if ct == "absence_required":
        return value == ABSENT

    # every other check_type needs an actual value to compare
    if value == ABSENT:
        return False

    if ct == "equals":
        return value.lower() == (rule.expected_value or "").lower()
    if ct == "not_equals":
        return value.lower() != (rule.expected_value or "").lower()

    if ct == "min_version":
        ov, ev = _version_tuple(value), _version_tuple(rule.expected_value or "")
        if not ov or not ev:
            return None
        return ov >= ev

    if ct in ("min_value", "max_value"):
        try:
            observed_num = float(value)
            expected_num = float(rule.expected_value)
        except (TypeError, ValueError):
            return None
        return observed_num >= expected_num if ct == "min_value" else observed_num <= expected_num

    if ct == "regex_match":
        if not rule.expected_value:
            return None
        return re.search(rule.expected_value, value, re.IGNORECASE) is not None

    if ct == "in_list":
        allowed = {v.lower() for v in (rule.expected_list or [])}
        return value.lower() in allowed
    if ct == "not_in_list":
        disallowed = {v.lower() for v in (rule.expected_list or [])}
        return value.lower() not in disallowed

    return None


def _fill_remediation(template: str, instance_id: Optional[str]) -> str:
    if instance_id and "{instance}" in template:
        return template.replace("{instance}", instance_id)
    return template


# ---------------------------------------------------------------------------
# Main evaluation
# ---------------------------------------------------------------------------

def group_by_control_area(fields) -> dict[str, list]:
    grouped = defaultdict(list)
    for f in fields:
        grouped[f.control_area.lower()].append(f)
    return grouped


def evaluate(device_id, fields, rules: list[ComplianceRule]) -> list[dict]:
    """
    Returns a list of finding dicts (swap this for your FindingDB ORM model --
    same field names, plus the new `instance_id` column).
    """
    grouped = group_by_control_area(fields)
    findings: list[dict] = []

    for rule in rules:
        instances = grouped.get(rule.control_area.lower(), [])

        if not instances:
            # The extractor for this control_area never produced anything at
            # all -- genuinely unknown, not "checked and absent".
            findings.append({
                "device_id": device_id,
                "control_id": rule.control_id,
                "instance_id": None,
                "status": "needs_review",
                "observed_value": None,
                "severity": rule.severity,
                "remediation_cli": rule.remediation_template,
                "raw_line": None,
            })
            continue

        for inst in instances:
            if inst.confidence < CONFIDENCE_THRESHOLD:
                status = "needs_review"
            else:
                result = _check_single(inst.value, rule)
                status = "needs_review" if result is None else ("pass" if result else "fail")

            findings.append({
                "device_id": device_id,
                "control_id": rule.control_id,
                "instance_id": inst.instance_id,
                "status": status,
                "observed_value": inst.value,
                "severity": rule.severity,
                "remediation_cli": None if status == "pass"
                    else _fill_remediation(rule.remediation_template, inst.instance_id),
                "raw_line": inst.raw_line,
            })

    return findings
